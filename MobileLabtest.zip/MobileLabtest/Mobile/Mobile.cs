﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mobile
{
    public class Mobile
    {
       
        public int  SL { get; set; }
        public string Modelname { get; set; }
        public string Imei{ get; set; }
        public string Price { get; set; }
        
    }
}