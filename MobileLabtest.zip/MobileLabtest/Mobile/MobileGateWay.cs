﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Mobile
{
    public class MobileGateWay : getway
    {
        public int Save(Mobile aMobile)
        {
            Connection.Open();
            Query = "INSERT INTO MobileHandset(Modelname,IMEI,Price) Values('" + aMobile.Modelname
                             + "','" + aMobile.Imei + "','" + aMobile.Price + "')";
            Command = new SqlCommand(Query, Connection);
            int rowCount = Command.ExecuteNonQuery();
            Connection.Close();
            return rowCount;
        }


        public bool IsExist(string iemi)
        {
            Connection.Open();
            Query = "SELECT * FROM MobileHandset  WHERE IMEI ='" + iemi + "'";
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            bool hasRow = Reader.HasRows;
            Reader.Close();
            Connection.Close();
            return hasRow;
        }


        public List<Mobile> GetAllMobile()
        {
            Connection.Open();
            Query = "SELECT * FROM MobileHandset";
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            List<Mobile> mobiles = new List<Mobile>();
            int SL = 0;

            while (Reader.Read())
            {
                Mobile aMobile = new Mobile();
                aMobile.Modelname = (string)Reader["Modelname"];
                aMobile.Imei = Reader["IMEI"].ToString();
                aMobile.Price = Reader["Price"].ToString();
                SL = SL + 1;
                aMobile.SL = SL;
                mobiles.Add(aMobile);
            }
            Reader.Close();
            Connection.Close();
            return mobiles;
        }

        public List<Mobile> GetSearchingMobiles(string firstprice, string secondprice)
        {
            Connection.Open();
            Query = "SELECT * FROM MobileHandset WHERE Price BETWEEN '" + firstprice + "' AND '" + secondprice + "';";
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            List<Mobile> mobiles = new List<Mobile>();
            int SL = 0;
            while (Reader.Read())
            {
                Mobile aMobile = new Mobile();
                aMobile.Modelname = (string)Reader["Modelname"];
                aMobile.Imei = Reader["IMEI"].ToString();
                aMobile.Price = Reader["Price"].ToString();
                SL = SL + 1;
                aMobile.SL = SL;
                mobiles.Add(aMobile);
            }
            Reader.Close();
            Connection.Close();
            return mobiles;
        }


        public List<Mobile> GetSearchingMobile(string imei)
        {
            Connection.Open();
            Query = "SELECT * FROM MobileHandset WHERE IMEI = '" + imei + "';";
            Command = new SqlCommand(Query, Connection);
            Reader = Command.ExecuteReader();
            List<Mobile> mobiles = new List<Mobile>();

            while (Reader.Read())
            {
                Mobile aMobile = new Mobile();
                aMobile.Modelname = (string)Reader["Modelname"];
                aMobile.Imei = Reader["IMEI"].ToString();
                aMobile.Price = Reader["Price"].ToString();
                mobiles.Add(aMobile);
            }
            Reader.Close();
            Connection.Close();
            return mobiles;
        }
    }
}