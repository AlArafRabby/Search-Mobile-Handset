﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Mobile
{
    public partial class Save : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        MobileManager aMobileManager = new MobileManager();

        protected void SaveButton_Click(object sender, EventArgs e)
        {
            Mobile amobile  = new Mobile();
            amobile.Modelname = ModelNameTextBox.Text;
            amobile.Imei = ImeiTextBox.Text;
            amobile.Price = PriceTextBox.Text;

            MessageLabel.Text = aMobileManager.Save(amobile);
        }

        
        
    }
}