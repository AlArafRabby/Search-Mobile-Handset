﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mobile
{
    public class MobileManager
    {
        MobileGateWay aMobileGateWay = new MobileGateWay();
        public bool IsExist(string iemi)
        {
            return aMobileGateWay.IsExist(iemi);
        }

        public string Save(Mobile aMobile)
        {
            if ((String.IsNullOrWhiteSpace(aMobile.Imei)||(aMobile.Imei.Length != 15)))
                return "IMEI is must be 15 Charecter and not allow any space in the 15 Charecter.";
            else
            {
                if (IsExist(aMobile.Imei))
                {
                    return "IMEI  is Already Exist.";
                }

                int rowAffected = aMobileGateWay.Save(aMobile);
                if (rowAffected > 0)
                    return "Saved";
                else
                {
                    return "Failed";
                }

            }

        }

        public List<Mobile> GetAllMobile()
        {
            return aMobileGateWay.GetAllMobile();
        }

        public List<Mobile> GetSearchingMobiles(string firstprice, string secondprice)
        {
            return aMobileGateWay.GetSearchingMobiles( firstprice,  secondprice);
        }


        public List<Mobile> GetSearchingMobile(string imei)
        {
            return aMobileGateWay.GetSearchingMobile(imei);
        }


    }
}