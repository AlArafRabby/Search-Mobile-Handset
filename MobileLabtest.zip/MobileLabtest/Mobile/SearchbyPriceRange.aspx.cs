﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Mobile
{
    public partial class SearchbyPriceRange : System.Web.UI.Page
    {
        MobileManager aMobileManager = new MobileManager();
        protected void Page_Load(object sender, EventArgs e)
        {
            List<Mobile> mobiles = aMobileManager.GetAllMobile();
            AllMobileGridView.DataSource = mobiles;
               AllMobileGridView.DataBind();
            

        }

        protected void SearchButton_Click(object sender, EventArgs e)
        {

            string firstprice, secondprice;
            firstprice = FristPriceTextBox.Text;
            secondprice = SecondPriceTextBox.Text;

            List<Mobile> mobiles = aMobileManager.GetSearchingMobiles(firstprice, secondprice);
            AllMobileGridView.DataSource = mobiles;
            AllMobileGridView.DataBind();
        }

       
        
    }
}