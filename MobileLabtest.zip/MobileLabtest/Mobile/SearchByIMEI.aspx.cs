﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Mobile
{
    public partial class SearchByIMEI : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        MobileManager aMobileManager = new MobileManager();
        protected void SearchButton_Click(object sender, EventArgs e)
        {
            Mobile aMobile = new Mobile();

            string Imei = ImeiSearchTextBox.Text;

            List<Mobile> mobiles = aMobileManager.GetSearchingMobile(Imei);
            foreach (var VARIABLE in mobiles)
            {
                aMobile.Modelname = VARIABLE.Modelname;
                aMobile.Imei = VARIABLE.Imei;
                aMobile.Price = VARIABLE.Price;
            }

            modelNameLabel.Text = aMobile.Modelname;
            iemiLabel.Text = aMobile.Imei;
            priceLabel.Text = aMobile.Price;



        }
    }
}